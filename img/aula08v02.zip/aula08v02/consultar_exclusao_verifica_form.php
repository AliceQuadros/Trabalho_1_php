<h1>Tem certeza que deseja excluir? </h1>
<form method="post">
    <input type="text" name="codigo" value="<?=@$codigo?>" size="2" readonly><br>
	<input type="submit" name="botao" value="sim">
    <input type="submit" name="botao" value="não">
</form>
