-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 01/10/2019 às 19:09
-- Versão do servidor: 10.4.6-MariaDB
-- Versão do PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `banco`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `contato`
--

CREATE TABLE `contato` (
  `conCodig` int(11) NOT NULL COMMENT 'código',
  `conEmail` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'e-mail',
  `conNome` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'nome',
  `conSobre` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'sobrenome',
  `conEstad` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'estado',
  `conCidad` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'cidade',
  `conDdd` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ddd',
  `conFone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'telefone',
  `conFixo` varchar(1) COLLATE utf8_unicode_ci DEFAULT '1' COMMENT 'fixo (1), cel (0)',
  `conMensa` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'mensagem',
  `conData` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'data e hora'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `contato`
--

INSERT INTO `contato` (`conCodig`, `conEmail`, `conNome`, `conSobre`, `conEstad`, `conCidad`, `conDdd`, `conFone`, `conFixo`, `conMensa`, `conData`) VALUES
(234, 'almcaruso@gmail.com', 'de', 'aedfa`', '', '', NULL, NULL, '1', NULL, '2019-10-01 14:07:32');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `contato`
--
ALTER TABLE `contato`
  ADD PRIMARY KEY (`conCodig`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `contato`
--
ALTER TABLE `contato`
  MODIFY `conCodig` int(11) NOT NULL AUTO_INCREMENT COMMENT 'código', AUTO_INCREMENT=235;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
