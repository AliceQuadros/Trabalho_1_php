<!-- altera.php -->
Alteração:
<form method="post">
    Código:<input type="text" name="codigo" value="<?=@$codigo?>" readonly><br>
	Nome: <input type="text" name="nome" value="<?=@$nome?>"><br>
    Sobrenome: <input type="text" name="sobrenome" value="<?=@$sobrenome?>"> <br>
    E-mail:  <input type="text" name="email" value="<?=@$email?>"> <br>
    Estado: <?=geraSelect($vetEstados,'estado',@$estado);?><br>
    Cidade: <input type="text" name="cidade" value="<?=@$cidade?>"> <br>
    DDD:<input type="text" name="ddd" value="<?=@$ddd?>">  Telefone: <input type="text" name="fone" value="<?=@$fone?>"> 
    tipo: <?=geraRadios(array('Fixo'=>'0','Celular'=>'1'),'fixo',@$fixo);?><br>
    Mensagem: <br> <textarea name="mensagem" cols="70" rows="10"><?=@$mensagem?></textarea> <br>
	<input type="submit" name="botao" value="salvar">
</form>
