<?php
//@ desliga notice na linha
//pega dados do $_REQUEST e guarda em variáveis locais
@$nome = $_REQUEST['nome'];
@$sobrenome = $_REQUEST['sobrenome'];
@$email =  $_REQUEST['email'];
@$estado =  $_REQUEST['estado'];
@$cidade =  $_REQUEST['cidade'];
@$fixo =  $_REQUEST['fixo'];
@$telefone  = $_REQUEST['fone'];
@$ddd = $_REQUEST['ddd'];
@$mensagem = $_REQUEST['mensagem'];

//botao enviar
if(isset($_REQUEST['botao'])){
    
    $erros = validaForm($_REQUEST, array('nome:texto:Nome é obrigatório',
                                         'sobrenome:texto:Sobrenome é obrigatório',
                                         'email:email:Deve ser um e-mail válido'));
    //validação
   if (strlen($erros)==0) {
    
    $novoCodigo = 0;
    $sql = "INSERT INTO `contato` (`conEmail`,`conNome`,`conSobre`, `conEstad`, `conCidad`) VALUES (?,?,?,?,?);";
    $retorno = fazConsultaSegura($sql,array($email,
                                            $nome,
                                            $sobrenome,
                                            $estado,
                                            $cidade
                                        ),$novoCodigo);
   
   //se o codigo do erro for diferente de null (não deu erro)
   //mostra o erro de erro na tela
   if($retorno[1] != null) {
        echo("<pre>Erro: <br>");
        print_r($retorno);
   } 
   else {//se não deu erro, dá a mensagem de incluído com sucesso
    echo("Registro incluído com sucesso com o código: $novoCodigo<hr>");

    //faz upload do arquivo
    if (isset($_FILES['arquivoParaUpload'])) {
     include("upload.php");
    
    }
   
   }

    //limpa variáveis do form
    /*$nome = '';     
    $sobrenome = '';
    $email =  '';
    $estado =  '';
    $cidade =  '';
    $fixo =  '';
    $fone  = '';
    $ddd = '';*/
   }
   else {
      echo ("$erros<hr>");
      include ("incluir_form.php");
   }

    
}//fim botao enviar
else {
    include ("incluir_form.php");
}
?>