<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="estilo.css"> 
    <title>CRUD 1.0</title>
</head>
<body>
    <div id="principal">
        <div id="topo">
            <div id="barra">
            topo
            </div>
            <div id="menu">
                <a href="?">Home</a> 
                <a href="?acao=incluir">Incluir</a> 
                <a href="?acao=consultar">Consultar</a> 
                <a href="?acao=excluir">Excluir</a> 
                <a href="?acao=alterar">Alteração</a> 
            </div>
        </div>
        <div id="conteudo">
           <?php
            include("funcoes_db.php");
            include("funcoes.php");
            if(isset($_REQUEST['acao'])) {
                $acao = $_REQUEST['acao'];
                switch ($acao) {
                    case "incluir"  :
                        include ("incluir.php");
                    break;
                    case "consultar"  :
                        include ("consultar_listar.php");
                    break;
                    case "excluir"  :
                        include ("consultar_exclusao.php");
                        include ("consultar_listar.php");
                    break;
                    case "alterar"  :
                        include ("consultar_alteracao.php");
                        include ("consultar_listar.php");
                    break;

                }
            }

           ?>
        </div>
        <div id="rodape">
            rodapé
        </div>
    </div>
</body>
</html>