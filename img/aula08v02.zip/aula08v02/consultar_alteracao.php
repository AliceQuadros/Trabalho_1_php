<?php
//testa se o botao  foi pressionado
if(isset($_REQUEST['botao'])){
     //carrega os dados para o form
    if ($_REQUEST['botao'] == 'alterar') {
       
        $codigo = $_REQUEST['codigo'];
        $sql = "select * from contato where conCodig=?";
        $resultado = fazConsultaSegura($sql,array($codigo));
        $registro = $resultado[0];

        $nome = $registro['conNome'];
        $sobrenome = $registro['conSobre'];
        $cidade = $registro['conCidad'];
        $email = $registro['conEmail'];
        $estado = $registro['conEstad'];
        $ddd = $registro['conDdd'];
        $fone = $registro['conFone'];
        $mensagem = $registro['conMensa'];
        $fixo = $registro['conFixo'];
        //mostra os dados no form
        include("consultar_alteracao_form.php");
    }
    else if ($_REQUEST['botao'] == 'salvar') {

        $erros = validaForm($_REQUEST, array('nome:texto:Nome é obrigatório',
                                         'sobrenome:texto:Sobrenome é obrigatório',
                                         'email:email:Deve ser um e-mail válido'));
        $codigo = $_REQUEST['codigo'];
        $nome = $_REQUEST['nome'];
        $sobrenome = ($_REQUEST['sobrenome']);
        $email =  $_REQUEST['email'];
        $estado =  $_REQUEST['estado'];
        $cidade =  $_REQUEST['cidade'];
        $fixo =  $_REQUEST['fixo'];
        $fone  = $_REQUEST['fone'];
        $ddd = $_REQUEST['ddd'];
        $mensagem = $_REQUEST['mensagem'];
       
                //validação
        if (strlen($erros)==0) {
                    //faz o update no banco
                   // $codigo = $_REQUEST['codigo'];

                    $sql = "UPDATE `contato` SET `conEmail` = ?, `conNome` = ?, `conSobre` = ?, `conEstad` = ?, `conCidad` = ?, `conDdd` = ?, `conFone` = ?, `conFixo` = ?, `conMensa` = ? WHERE `conCodig` = ?";
                    $retorno = fazConsultaSegura($sql,array($email,
                                                            $nome,
                                                            $sobrenome,
                                                            $estado,
                                                            $cidade,
                                                            $ddd,
                                                            $fone,
                                                            $fixo,
                                                            $mensagem,
                                                            $codigo));
                   
                   // print_r($retorno);
                    //limpa variáveis do form
                    $nome = '';
                    $sobrenome = '';
                    $email =  '';
                    $estado =  '';
                    $cidade =  '';
                    $fixo =  '';
                    $fone  = '';
                    $ddd = '';
                    $mensagem = '';

            }
            else {
                echo("$erros<hr>");
                include("consultar_alteracao_form.php");
            }
        }
}
    




?>
