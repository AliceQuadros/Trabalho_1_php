<?php
$diretorio_alvo = "uploads/";
//$_FILES é um vetor associativo especial que
//contém dados sobre os arquivos que serão enviados

$tipoArquivoImagem = strtolower(pathinfo($_FILES["arquivoParaUpload"]["name"],PATHINFO_EXTENSION));
$arquivo_alvo = $diretorio_alvo . basename($novoCodigo) . "." . $tipoArquivoImagem;
//move_uploaded_file faz a cópia do arquivo
//para a pasta apropriada
//se ocorrer erro, retorna false
if (move_uploaded_file($_FILES["arquivoParaUpload"]["tmp_name"], $arquivo_alvo)) {
    echo "Arquivo ". basename( $_FILES["arquivoParaUpload"]["name"]). " foi enviado com sucesso.<br>";
} else {
    echo "Ocorreu um erro enviando seu arquivo.<br>";
}

?>