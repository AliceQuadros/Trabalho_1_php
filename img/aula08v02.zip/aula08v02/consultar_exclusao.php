<?php
//testa se o botao excluir foi pressionado
if(isset($_REQUEST['botao'])){
	//testa se o botao excluir ou "sim" foi pressionado
	if ($_REQUEST['botao'] == 'excluir'){
		//pede confirmacao
		$codigo = $_REQUEST['codigo'];
		include("consultar_exclusao_verifica_form.php");
	}
	else  if ($_REQUEST['botao'] == 'sim'){
		//faz exclusão
		$codigo = $_REQUEST['codigo'];
		$sql = "delete from contato where conCodig = ?";
		fazConsultaSegura($sql,array($codigo));
	}
}

?>
