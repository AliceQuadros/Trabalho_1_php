<form method="post">
<table class="tableconsulta">

    <tr>
        <td>Nome</td> 
        <td>
        <?=$registro['conNome'];?> <?=$registro['conSobre'];?>
        </td>
        <td>
            
        </td>
    </tr>
    <tr>
        <td>Email:</td>
        <td>
        <?=$registro['conEmail'];?>
        </td>
        <td></td>
    </tr>
    <tr>
        <td>Cidade/Estado:</td>
        <td>
        <?=$registro['conCidad'];?> / <?=$registro['conEstad'];?> 
        </td>
        <td></td>
    </tr>
    <tr>
        <td>Telefone:</td>
        <td>
        (<?=$registro['conDdd'];?>) <?=$registro['conFone'];?> 
        </td>
        <td></td>
    </tr>
    <tr>
        <td>Mensagem:</td>
        <td>
        (<?=$registro['conMensa'];?>)
        </td>
        <td></td>
    </tr>
</table><br>
</form>