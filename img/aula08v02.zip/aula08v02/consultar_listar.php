<form method="post">
	Buscar nome:<input type="text" name="busca"><br>
	Email:<input type="text" name="busca2"><br>
	<input type="submit" value="ok">
</form>
<?php

if (isset($_REQUEST['busca'])) {
	$busca = trim($_REQUEST['busca']);
}
else {
	$busca = '';
}

if (isset($_REQUEST['busca2'])) {
	$busca2 = trim($_REQUEST['busca2']);
}
else {
	$busca2 = '';
}

if ((strlen($busca) >0) and (strlen($busca2)>0)){
	$sql = "select * from contato where conNome LIKE ? OR conEmail LIKE ?";
	$busca = "$busca" . "%";
	$busca2 = "$busca2" . "%";
	$vetorPars = array($busca,		   
					   $busca2);
	$resultado = fazConsultaSegura($sql,$vetorPars);
}
else if ((strlen($busca) >0) and (strlen($busca2)==0)) {
	$sql = "select * from contato where conNome LIKE ?";
	$vetorPars = array($busca .'%');
	$resultado = fazConsultaSegura($sql,$vetorPars);
} else if ((strlen($busca)==0) and (strlen($busca2)>0)) {
	$sql = "select * from contato where conEmail LIKE ?";
	$vetorPars = array($busca2 .'%');
	$resultado = fazConsultaSegura($sql,$vetorPars);
 } else {
	$sql = "select * from contato order by conCodig desc";
	$resultado = fazConsultaSegura($sql);
 }

//se deu tudo certo, fazConsulta() retorna um ARRAY com os registros
if (is_array($resultado)) {
	
	//$acao está definida em index
	//escolhe qual ficha será usada na listagen
	switch($acao){
		case "alterar" : 
			$ficha = "consultar_alteracao_ficha.php";
		break;
		case "excluir" : 
			$ficha = "consultar_exclusao_ficha.php";
		break;
		default :
			$ficha = "consultar_listar_ficha.php";
	}
	//enquanto tem registros disponíveis 
	//na consulta, copia cada um deles 
	//para o vetor associativo $registro 
	//print_r($resultado);
	if(count($resultado) >0) {
		
		foreach($resultado as $registro) {
			include($ficha);
		}
	}
	else {
		echo("Nenhum registro encontrado");
	}
}
else { //caso contrário mostra o erro retornado
	echo("<pre>");
	print_r($resultado);
}

?>