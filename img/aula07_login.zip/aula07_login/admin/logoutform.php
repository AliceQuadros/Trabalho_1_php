<form method="post" action="login.php">
	<input type="submit" name="login" value="sair">
</form>