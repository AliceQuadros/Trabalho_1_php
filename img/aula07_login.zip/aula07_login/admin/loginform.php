<form method="post" action="login.php">
	<input type="text" name="user" placeholder="usuário" size="8">
	<input type="password" name="pass" placeholder="senha" size="8">
	<input type="submit" name="login" value="ok">
</form>