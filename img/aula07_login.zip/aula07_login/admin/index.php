<?php
include ("verificalogin.php");
?>
<h1>Aqui vai qqr conteúdo que seja obrigatório 
estar logado para ver!</h1>