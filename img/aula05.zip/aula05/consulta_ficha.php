<table>
    <tr>
        <td>Nome</td> 
        <td>
        <?=$registro['conNome'];?> <?=$registro['conSobre'];?>
        </td>
    </tr>
    <tr>
        <td>Email:</td>
        <td>
        <?=$registro['conEmail'];?>
        </td>
    </tr>
    <tr>
        <td>Cidade/Estado:</td>
        <td>
        <?=$registro['conCidad'];?> / <?=$registro['conEstad'];?> 
        </td>
    </tr>
    <tr>
        <td>Telefone:</td>
        <td>
        (<?=$registro['conDdd'];?>) <?=$registro['conFone'];?> 
        </td>
    </tr>
    <tr>
        <td>Mensagem:</td>
        <td>
        (<?=$registro['conMensa'];?>)
        </td>
    </tr>
</table><br>