<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="estilo.css"> 
<?php
//inclui.php
include("funcoes_db.php");
include("inclui_form.php");

//botao enviar
if(isset($_REQUEST['botao'])){
	$nome = $_REQUEST['nome'];
    $sobrenome = ($_REQUEST['sobrenome']);
    $email =  $_REQUEST['email'];
    $estado =  $_REQUEST['estado'];
    $cidade =  $_REQUEST['cidade'];
    $fixo =  $_REQUEST['fixo'];
    $telefone  = $_REQUEST['telefone'];
    $ddd = $_REQUEST['ddd'];
    $mensagem = $_REQUEST['mensagem'];
	$sql = "INSERT INTO `contato` (`conCodig`, `conEmail`, `conNome`, `conSobre`, `conEstad`, `conCidad`, `conDdd`, `conFone`, `conFixo`, `conMensa`, `conData`) VALUES (NULL, '$email', '$nome', '$sobrenome', '$estado', '$cidade', '$ddd', '$telefone', '$fixo', '$mensagem',CURRENT_TIMESTAMP);";
    $retorno = fazConsulta($sql);
    //print_r($retorno);
    
}//fim botao enviar
//lista todos os registros após a inclusão
include("consulta.php");

?>