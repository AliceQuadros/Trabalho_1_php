<!-- inclui_form.php -->
<form method="post">
	Nome: <input type="text" name="nome"><br>
    Sobrenome: <input type="text" name="sobrenome"> <br>
    E-mail:  <input type="text" name="email"> <br>
    Estado: <input type="text" name="estado" maxlength="2" size="2"> <br>
    Cidade: <input type="text" name="cidade"> <br>
    DDD:<input type="text" name="ddd">  Telefone: <input type="text" name="telefone"> 
    tipo: <input type="radio" name="fixo" value="1">fixo 
    <input type="radio" name="fixo" value="0" checked>celular<br>
    Mensagem: <br> <textarea name="mensagem" cols="70" rows="10"></textarea> <br>
	<input type="submit" name="botao" value="OK">
</form>
