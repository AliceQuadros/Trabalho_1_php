<?php
//monta o SQL
$sql = "select * from contato order by conCodig desc";
//consulta o banco passando a conexao e o sql
$resultado = fazConsulta($sql);

//se deu tudo certo, fazConsulta() retorna um ARRAY com os registros
if (is_array($resultado)) {
	//enquanto tem registros disponíveis 
	//na consulta, copia cada um deles 
	//para o vetor associativo $registro 
	foreach($resultado as $registro) {
		include("consulta_ficha.php");
	}
}
else { //caso contrário mostra o erro retornado
	echo("<pre>");
	print_r($resultado);
}


?>